# ADS1115
Arduino library for the ADS1115 Analog-to-Digital Converter

## Original Repository:
From https://github.com/jrowberg/i2cdevlib
